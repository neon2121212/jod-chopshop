local QBCore = exports['qb-core']:GetCoreObject()

-- Criar blip para do mapa
Citizen.CreateThread(function()
    local blip = AddBlipForCoord(480.41, -1318.27, 29.2) -- Mudar coordenadas do blip aqui!
	SetBlipSprite(blip, 566) -- Mudar estilo do blip aqui!
	SetBlipDisplay(blip, 2)
	SetBlipScale(blip, 0.7)
	SetBlipAsShortRange(blip, true)
	SetBlipColour(blip, 28) -- Mudar cor aqui!
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentSubstringPlayerName("Chopshop") -- Mudar nome do Blip aqui!
    EndTextCommandSetBlipName(blip)
end)

RegisterNetEvent('jod-chopshop:client:Desmanchar')
AddEventHandler("jod-chopshop:client:Desmanchar", function()
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
    QBCore.Functions.Progressbar("Desmanchar", "Destroying Vehicle..", 15000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() 
        local veh = GetVehiclePedIsIn(PlayerPedId(),true)
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(5,20)
   if success then
        DeleteVehicle(veh)
        DeleteEntity(veh)
        TriggerServerEvent("jod-chopshop:server:Desmanchar")
    else
        QBCore.Functions.Notify("Failed!", "error")
        end
    end)
    else
        QBCore.Functions.Notify("You need to be in a vehicle to destroy that!", "error", 4500)
    end
end)

-- Evento da ProgressBar
RegisterNetEvent('jod-chopshop:client:DesmancharMotor')
AddEventHandler("jod-chopshop:client:DesmancharMotor", function()
    QBCore.Functions.Progressbar("DesmancharMotor", "Destroying Vehicle Engine", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 16,
    }, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        StopAnimTask(ped, dict, "machinic_loop_mechandplayer", 1.0)
        TriggerServerEvent("jod-chopshop:server:DesmancharMotor")
        ClearPedTasks(playerPed)
    else
        QBCore.Functions.Notify("Failed!", "error")
        ClearPedTasks(playerPed)
        end
    end)
end)

RegisterNetEvent('jod-chopshop:client:DesmancharFarois')
AddEventHandler("jod-chopshop:client:DesmancharFarois", function()
    QBCore.Functions.Progressbar("DesmancharFarois", "Destroying Vehicle Lights", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 16,
    }, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        StopAnimTask(ped, dict, "machinic_loop_mechandplayer", 1.0)
        TriggerServerEvent("jod-chopshop:server:DesmancharFarois")
        ClearPedTasks(playerPed)
    else
        QBCore.Functions.Notify("Failed!", "error")
        ClearPedTasks(playerPed)
        end
    end)
end)

RegisterNetEvent('jod-chopshop:client:DesmancharPortas')
AddEventHandler("jod-chopshop:client:DesmancharPortas", function()
    QBCore.Functions.Progressbar("DesmancharPortas", "Destroying Vehicle Doors", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 16,
    }, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        StopAnimTask(ped, dict, "machinic_loop_mechandplayer", 1.0)
        TriggerServerEvent("jod-chopshop:server:DesmancharPortas")
        ClearPedTasks(playerPed)
    else
        QBCore.Functions.Notify("Failed!", "error")
        ClearPedTasks(playerPed)
        end
    end)
end)

RegisterNetEvent('jod-chopshop:client:DesmancharVidros')
AddEventHandler("jod-chopshop:client:DesmancharVidros", function()
    QBCore.Functions.Progressbar("DesmancharVidros", "Destrying Vehicle Glasses", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 16,
    }, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        StopAnimTask(ped, dict, "machinic_loop_mechandplayer", 1.0)
        TriggerServerEvent("jod-chopshop:server:DesmancharVidros")
        ClearPedTasks(playerPed)
    else
        QBCore.Functions.Notify("Failed!", "error")
        ClearPedTasks(playerPed)
        end
    end)
end)

RegisterNetEvent('jod-chopshop:client:DesmancharPneus')
AddEventHandler("jod-chopshop:client:DesmancharPneus", function()
    QBCore.Functions.Progressbar("DesmancharPneus", "Destroying Vehicle Tires", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 16,
    }, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        StopAnimTask(ped, dict, "machinic_loop_mechandplayer", 1.0)
        TriggerServerEvent("jod-chopshop:server:DesmancharPneus")
        ClearPedTasks(playerPed)
    else
        QBCore.Functions.Notify("Failed!", "error")
        ClearPedTasks(playerPed)
        end
    end)
end)

RegisterNetEvent('jod-chopshop:client:DesmancharRodas')
AddEventHandler("jod-chopshop:client:DesmancharRodas", function()
    QBCore.Functions.Progressbar("DesmancharRodas", "Destroying Vehicle Wheels", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_player",
        flags = 16,
    }, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        StopAnimTask(ped, dict, "machinic_loop_mechandplayer", 1.0)
        TriggerServerEvent("jod-chopshop:server:DesmancharRodas")
        ClearPedTasks(playerPed)
    else
        QBCore.Functions.Notify("Failed!", "error")
        ClearPedTasks(playerPed)
        end
    end)
end)

RegisterNetEvent('jod-chopshop:client:DesmancharParachoques')
AddEventHandler("jod-chopshop:client:DesmancharParachoques", function()
    QBCore.Functions.Progressbar("DesmancharParachoques", "Destroying Vehicle Bumpers", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() 
        local playerPed = PlayerPedId()
        local success = exports['qb-lock']:StartLockPickCircle(1,30)
   if success then
        TriggerServerEvent("jod-chopshop:server:DesmancharParachoques")
    else
        QBCore.Functions.Notify("Failed!", "error")
        end
    end)
end)

-- Menu para venda das peças
RegisterNetEvent('jod-chopshop:client:MenuDesmache', function()
    exports['qb-menu']:openMenu({
        {
            id = 1,
            header = "Destroy Car Parts",
            txt = ""
        },
        {
            id = 2,
            header = "Vehicle Engine",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharMotor",
            }
        },
        {
            id = 3,
            header = "Car Doors",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharPortas",
            }
        },
        {
            id = 4,
            header = "Car Glasses",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharVidros",
            }
        },
        {
            id = 5,
            header = "Car Tires",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharPneus",
            }
        },
        {
            id = 6,
            header = "Car Bumpers",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharParachoques",
            }
        },
        {
            id = 7,
            header = "Car Lights",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharFarois",
            }
        },
        {
            id = 8,
            header = "Car Wheels",
            txt = "",
            params = {
                event = "jod-chopshop:client:DesmancharRodas",
            }
        },
        {
            id = 9,
            header = "< Close",
            txt = "",
            params = {
                event = "qb-menu:closeMenu",
            }
        },
    })
end)

-- Target para desmanchar
CreateThread(function() 
    exports['qb-target']:AddBoxZone("Desmanche", vector3(480.85, -1319.45, 28.6), 20, 20,  {
      name = "Desmanche",
      heading = 0,
      debugPoly = false,
    }, {
      options = {
        {
          type = "client",
          event = "jod-chopshop:client:Desmanchar",
          icon = 'fas fa-car',
          label = 'Destroy vehicle',
          canInteract = function()
            if IsPedInAnyVehicle(PlayerPedId(), false) then return true end
          end,
        }
      },
      distance = 5,
    })
end)

-- Target para desmanchar peças
CreateThread(function()
    exports['qb-target']:AddBoxZone("DesmanchePecas", vector3(487.99, -1304.99, 29.33), 2, 2,  {
      name = "DesmanchePecas",
      heading = 0,
      debugPoly = false,
    }, {
      options = {
        {
          type = "client",
          event = "jod-chopshop:client:MenuDesmache",
          icon = 'fas fa-car',
          label = 'Destroy Car Parts',
        }
      },
      distance = 2.5,
    })
end)
