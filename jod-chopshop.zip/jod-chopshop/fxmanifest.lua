fx_version 'cerulean'

game 'gta5'

author 'jod scripts'

description 'jod-chopshop'

version '0.1'

client_scripts{
    'client.lua',
}

server_scripts{
    'server.lua',
}